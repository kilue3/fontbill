import React from 'react'
import { Button } from 'reactstrap';
const Manage = () => {
    return (
        <>
            <Button className="Button-Style" size="lg" block>ข้อมูลทุนการศึกษา</Button>
            <Button className="Button-Style" size="lg" block>หมวดหมู่ทุนการศึกษา</Button>
            <Button className="Button-Style" size="lg" block>หน่วยงานทุนการศึกษา</Button>
            <Button className="Button-Style" size="lg" block>อนุมัติผู้ใช้งาน</Button>

        </>
    )
}

export default Manage;
